import gradio as gr
from pytube import YouTube      
from moviepy.editor import *
def download_youtube_video(youtube_url):
    yt = YouTube(youtube_url)
    yt.streams.first().download(filename=f"{yt.title}.mp4")
    
    clip = VideoFileClip(f"{yt.title}.mp4")
    clip.audio.write_audiofile(f"{yt.title}.mp3")
    return yt.title, yt.thumbnail_url, f"{yt.title}.mp3"
demo = gr.Interface(download_youtube_video, "textbox", outputs=["textbox","image","audio"])
demo.launch()

